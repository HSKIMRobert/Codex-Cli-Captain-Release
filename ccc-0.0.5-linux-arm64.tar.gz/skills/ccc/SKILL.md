---
name: ccc
description: Plugin distribution surface for Codex-Cli-Captain; keep $cap as the public CCC entry point.
metadata:
  short-description: CCC plugin package
---

# CCC Plugin

Install/discovery metadata for CCC packaging. Use when the packaged CCC skill
needs to be discovered, cached, or activated by the host tooling.

## Public Contract

- `$cap` remains the public CCC entry point.
- The packaged CCC skill exists to make `$cap` discoverable through install and
  cache surfaces.
- `skills/ccc` is not a user command surface.
- Keep internal CCC lifecycle and diagnostic actions out of the public plugin
  surface.
- Do not present plugin/UI affordances as replacements for `$cap`.
- When an operator wants CCC to run work, preserve the `$cap ...` request form.

## Install and Discovery Notes

- Treat this packaged skill as install/discovery metadata, not as a runbook or
  command surface.
- The host may use the packaged asset for discovery, activation, or cache
  refresh, but those affordances stay secondary to `$cap`.
- Any execution guidance belongs in persisted CCC memory or captain guidance,
  not in this packaged skill.
